# Forward Testing Requirements

## Testing Strategy
1. Train on 100% of historical data up to test period
2. Implement walk-forward testing across different market conditions
3. Test across eight market regimes with specific date ranges and characteristics:

## Market Regimes

### 1. Financial Crisis (2007-10-09 to 2009-03-09)
- **Characteristics**:
  - Extreme volatility
  - Liquidity crisis
  - S&P 500 drawdown: -56.8%
- **Test Period**: 2008-01-01 to 2009-03-09

### 2. Post-Crisis Recovery (2009-03-10 to 2011-04-29)
- **Characteristics**:
  - Strong bull market
  - QE-driven liquidity
  - S&P 500 return: +102.5%
- **Test Period**: 2009-06-01 to 2011-04-29

### 3. Sideways/Bear (2011-05-02 to 2016-02-11)
- **Characteristics**:
  - Range-bound with volatility spikes
  - Multiple 10%+ corrections
  - S&P 500 return: +37.2% (annualized: +6.7%)
- **Key Events**:
  - US Debt Downgrade (2011)
  - Taper Tantrum (2013)
  - Oil Price Collapse (2014-2016)
- **Test Period**: 2012-01-03 to 2016-02-11

### 4. Post-Election Rally (2016-02-12 to 2018-09-20)
- **Characteristics**:
  - Low volatility
  - Steady uptrend
  - S&P 500 return: +68.7%
- **Test Period**: 2016-06-01 to 2018-09-20

### 5. Late-Cycle Volatility (2018-09-21 to 2020-02-19)
- **Characteristics**:
  - Increased volatility
  - Trade war concerns
  - S&P 500 return: +15.3%
- **Test Period**: 2019-01-01 to 2020-02-19

### 6. COVID Crash & Recovery (2020-02-20 to 2021-12-31)
- **Characteristics**:
  - Extreme volatility
  - Unprecedented fiscal/monetary response
  - S&P 500 return: +114.4%
- **Test Periods**:
  - Crash: 2020-02-20 to 2020-03-23
  - Recovery: 2020-03-24 to 2021-12-31

### 7. Inflation/Tightening (2022-01-03 to 2023-12-29)
- **Characteristics**:
  - High inflation
  - Aggressive Fed hiking cycle
  - S&P 500 drawdown: -25.4% (peak to trough)
- **Key Events**:
  - Russia-Ukraine War
  - 40-year high inflation
  - Regional bank failures
- **Test Period**: 2022-03-01 to 2023-12-29

### 8. Current Regime (2024-01-02 to Present)
- **Characteristics**:
  - Disinflation
  - Fed pause/pivot
  - AI boom
- **Test Period**: 2024-03-01 to Present

## Implementation Details
- Use real market data only (no synthetic data)
- For each test period:
  - Train on all data up to test period start
  - Walk-forward test through the test period
  - Track performance metrics
- Compare against buy-and-hold strategy
- Track confidence scores for each prediction

## Key Metrics
- Direction accuracy
- Risk-adjusted returns (Sharpe/Sortino ratios)
- Maximum drawdown
- Win rate
- Confidence score distribution

## Output Requirements
- Performance metrics by market regime and test period
- Confidence score analysis
- Trade simulation results
- Regime-specific performance comparison

## Charting Requirements

### 1. Price Prediction Chart (Per Regime)
- **Primary Y-axis (Left):**
  - Actual price line (solid blue)
  - Predicted price line (dashed orange)
- **Secondary Y-axis (Right):**
  - Prediction confidence (0-100%)
- **Elements:**
  - Green shaded areas: Correct direction predictions
  - Red shaded areas: Incorrect direction predictions
  - Vertical dashed lines: Major market events during the period
  - Interactive tooltips showing:
    - Date
    - Actual price
    - Predicted price
    - Confidence level
    - Prediction direction (up/down)

### 2. Direction Accuracy Heatmap (Per Regime)
- **X-axis:** Prediction horizon (1-30 days)
- **Y-axis:** Confidence threshold (0-100%)
- **Color intensity:** Accuracy percentage
- **Purpose:** Helps identify optimal confidence thresholds for trading

### 3. Performance Comparison Chart
- **Bars showing:**
  - Model return (annualized)
  - Buy & hold return (annualized)
  - Benchmark return (e.g., SPY, QQQ)
- **Secondary metrics (as text boxes):**
  - Win rate
  - Sharpe ratio
  - Maximum drawdown
  - Average confidence on correct vs incorrect predictions

### 4. Confidence Distribution Chart
- **Histogram of confidence scores** for:
  - Correct predictions
  - Incorrect predictions
- **Ideal:** Clear separation between the two distributions

### 5. Trade Simulation Chart
- **Upper panel:**
  - Equity curve (model vs buy & hold)
  - Drawdown curve
- **Lower panel:**
  - Position sizing based on confidence
  - Entry/exit points

### Technical Implementation
- Use Plotly for interactive visualizations
- Enable zoom, pan, and download as PNG
- Responsive design for different screen sizes
- Dark/light mode support
- Export to HTML for easy sharing

### Chart Update Frequency
- Regenerate after each walk-forward step during backtesting
- Store all charts with timestamps for historical comparison
- Generate animated versions showing model evolution over time

### Accessibility
- Colorblind-friendly color schemes
- High contrast mode
- Keyboard navigation support
- Text alternatives for all visual elements
