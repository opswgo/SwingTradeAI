"""
SwingTradeAI - Data Pipeline
User Acceptance: Clean, validated data with clear error reporting
"""

import asyncio
import pandas as pd
import yfinance as yf
import duckdb
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Tuple
from pathlib import Path
import sqlalchemy as sa
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import sessionmaker

from ..core.config import Settings
from ..core.logger import setup_logger, log_data_quality, log_system_health, log_user_action

logger = setup_logger(__name__)


class DataValidationError(Exception):
    """Custom exception for data validation issues."""
    pass


class DataPipeline:
    """
    Main data pipeline with user-focused validation and error reporting.
    User Acceptance: User sees clean, validated data with clear error reporting
    """
    
    def __init__(self, settings: Settings):
        self.settings = settings
        self.db_engine = None
        self.async_session = None
        self.duckdb_conn = None
        
        # Data quality thresholds
        self.quality_thresholds = {
            'completeness': 0.95,  # 95% of expected data points
            'accuracy': 0.98,      # 98% valid values
            'timeliness': 24       # Data not older than 24 hours
        }
    
    async def initialize(self) -> Dict[str, Any]:
        """Initialize data pipeline with user feedback."""
        logger.info("🔧 Initializing data pipeline...")
        
        try:
            # Setup database connections
            await self._setup_database_connections()
            
            # Initialize DuckDB for backtesting
            await self._setup_duckdb()
            
            # Create database schema
            await self._create_schema()
            
            # Validate data sources
            await self._validate_data_sources()
            
            logger.info("✅ Data pipeline initialized successfully")
            return {'success': True, 'message': 'Data pipeline ready'}
            
        except Exception as e:
            logger.error(f"❌ Data pipeline initialization failed: {str(e)}")
            return {'success': False, 'error': str(e)}
    
    async def _setup_database_connections(self):
        """Setup async database connections."""
        try:
            # PostgreSQL connection
            db_url = self.settings.DATABASE_URL.replace('postgresql://', 'postgresql+asyncpg://')
            self.db_engine = create_async_engine(
                db_url,
                pool_size=10,
                max_overflow=20,
                pool_timeout=30,
                pool_recycle=3600,
                echo=self.settings.LOG_LEVEL == "DEBUG"
            )
            
            self.async_session = sessionmaker(
                self.db_engine, 
                class_=AsyncSession, 
                expire_on_commit=False
            )
            
            logger.info("✅ Database connections established")
            
        except Exception as e:
            logger.error(f"❌ Database connection failed: {str(e)}")
            raise
    
    async def _setup_duckdb(self):
        """Setup DuckDB for backtesting with persistence."""
        try:
            duckdb_path = self.settings.DATA_DIR / "backtests" / "trading_data.duckdb"
            duckdb_path.parent.mkdir(parents=True, exist_ok=True)
            
            self.duckdb_conn = duckdb.connect(str(duckdb_path))
            
            # Create backtesting tables
            self.duckdb_conn.execute("""
                CREATE TABLE IF NOT EXISTS historical_prices (
                    symbol VARCHAR,
                    date DATE,
                    open DOUBLE,
                    high DOUBLE,
                    low DOUBLE,
                    close DOUBLE,
                    volume BIGINT,
                    adjusted_close DOUBLE,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            self.duckdb_conn.execute("""
                CREATE TABLE IF NOT EXISTS options_data (
                    symbol VARCHAR,
                    expiration DATE,
                    strike DOUBLE,
                    option_type VARCHAR,
                    bid DOUBLE,
                    ask DOUBLE,
                    volume BIGINT,
                    open_interest BIGINT,
                    implied_volatility DOUBLE,
                    date DATE,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            logger.info("✅ DuckDB backtesting database ready")
            
        except Exception as e:
            logger.error(f"❌ DuckDB setup failed: {str(e)}")
            raise
    
    async def _create_schema(self):
        """Create database schema for user data tracking."""
        schema_sql = """
        -- User activity tracking
        CREATE TABLE IF NOT EXISTS user_actions (
            id SERIAL PRIMARY KEY,
            action VARCHAR(100) NOT NULL,
            details JSONB,
            success BOOLEAN DEFAULT TRUE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        
        -- Data quality metrics
        CREATE TABLE IF NOT EXISTS data_quality_metrics (
            id SERIAL PRIMARY KEY,
            dataset VARCHAR(100) NOT NULL,
            quality_score FLOAT NOT NULL,
            completeness FLOAT,
            accuracy FLOAT,
            timeliness_hours FLOAT,
            issues JSONB,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        
        -- System health tracking
        CREATE TABLE IF NOT EXISTS system_health (
            id SERIAL PRIMARY KEY,
            component VARCHAR(100) NOT NULL,
            healthy BOOLEAN NOT NULL,
            details JSONB,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        
        -- Market data cache
        CREATE TABLE IF NOT EXISTS market_data_cache (
            id SERIAL PRIMARY KEY,
            symbol VARCHAR(20) NOT NULL,
            data_type VARCHAR(50) NOT NULL,
            data JSONB NOT NULL,
            expires_at TIMESTAMP NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        
        CREATE INDEX IF NOT EXISTS idx_market_data_symbol ON market_data_cache(symbol);
        CREATE INDEX IF NOT EXISTS idx_market_data_type ON market_data_cache(data_type);
        CREATE INDEX IF NOT EXISTS idx_market_data_expires ON market_data_cache(expires_at);
        """
        
        try:
            async with self.db_engine.begin() as conn:
                await conn.execute(sa.text(schema_sql))
            logger.info("✅ Database schema created/updated")
        except Exception as e:
            logger.error(f"❌ Schema creation failed: {str(e)}")
            raise
    
    async def _validate_data_sources(self):
        """Validate external data sources for user feedback."""
        validation_results = {}
        
        # Test yfinance
        try:
            test_symbol = "AAPL"
            ticker = yf.Ticker(test_symbol)
            info = ticker.info
            if info and 'symbol' in info:
                validation_results['yfinance'] = {'status': 'healthy', 'message': 'Connected successfully'}
            else:
                validation_results['yfinance'] = {'status': 'warning', 'message': 'Limited data available'}
        except Exception as e:
            validation_results['yfinance'] = {'status': 'error', 'message': str(e)}
        
        # Log results for user visibility
        for source, result in validation_results.items():
            if result['status'] == 'healthy':
                logger.info(f"✅ Data source {source}: {result['message']}")
            elif result['status'] == 'warning':
                logger.warning(f"⚠️ Data source {source}: {result['message']}")
            else:
                logger.error(f"❌ Data source {source}: {result['message']}")
        
        return validation_results
    
    async def fetch_historical_data(
        self, 
        symbol: str, 
        period: str = "1y",
        validate: bool = True
    ) -> Tuple[pd.DataFrame, Dict[str, Any]]:
        """
        Fetch historical data with user-focused validation.
        
        Returns:
            Tuple of (data_frame, validation_report)
        """
        log_user_action(f"fetch_historical_data", {"symbol": symbol, "period": period})
        
        try:
            # Fetch data from yfinance
            ticker = yf.Ticker(symbol)
            data = ticker.history(period=period)
            
            if data.empty:
                raise DataValidationError(f"No data available for symbol {symbol}")
            
            # Validate data if requested
            validation_report = {}
            if validate:
                validation_report = await self._validate_market_data(data, symbol)
            
            # Store in DuckDB for backtesting
            await self._store_historical_data(symbol, data)
            
            # Log data quality
            quality_score = validation_report.get('overall_score', 1.0)
            log_data_quality(f"historical_{symbol}", quality_score, validation_report.get('issues', []))
            
            logger.info(f"✅ Fetched {len(data)} records for {symbol}")
            return data, validation_report
            
        except Exception as e:
            logger.error(f"❌ Failed to fetch data for {symbol}: {str(e)}")
            log_user_action(f"fetch_historical_data", {"symbol": symbol, "error": str(e)}, success=False)
            raise DataValidationError(f"Data fetch failed for {symbol}: {str(e)}")
    
    async def _validate_market_data(self, data: pd.DataFrame, symbol: str) -> Dict[str, Any]:
        """Comprehensive data validation with user-friendly reporting."""
        validation_report = {
            'symbol': symbol,
            'total_records': len(data),
            'date_range': {
                'start': data.index.min().strftime('%Y-%m-%d'),
                'end': data.index.max().strftime('%Y-%m-%d')
            },
            'issues': [],
            'warnings': [],
            'metrics': {}
        }
        
        # Check completeness
        expected_columns = ['Open', 'High', 'Low', 'Close', 'Volume']
        missing_columns = [col for col in expected_columns if col not in data.columns]
        if missing_columns:
            validation_report['issues'].append(f"Missing columns: {missing_columns}")
        
        # Check for missing values
        null_counts = data.isnull().sum()
        if null_counts.any():
            validation_report['warnings'].append(f"Null values found: {null_counts.to_dict()}")
        
        # Check data consistency
        if 'High' in data.columns and 'Low' in data.columns:
            invalid_high_low = (data['High'] < data['Low']).sum()
            if invalid_high_low > 0:
                validation_report['issues'].append(f"{invalid_high_low} records with High < Low")
        
        # Check for outliers (price changes > 50% in one day)
        if 'Close' in data.columns:
            pct_change = data['Close'].pct_change().abs()
            extreme_changes = (pct_change > 0.5).sum()
            if extreme_changes > 0:
                validation_report['warnings'].append(f"{extreme_changes} extreme price changes (>50%)")
        
        # Calculate quality metrics
        completeness = 1 - (data.isnull().sum().sum() / (len(data) * len(data.columns)))
        accuracy = 1 - (len(validation_report['issues']) * 0.1)  # Each issue reduces accuracy by 10%
        
        # Check timeliness
        latest_date = data.index.max()
        hours_old = (datetime.now() - latest_date.to_pydatetime().replace(tzinfo=None)).total_seconds() / 3600
        timeliness = max(0, 1 - (hours_old / 168))  # Degrade over 1 week
        
        validation_report['metrics'] = {
            'completeness': completeness,
            'accuracy': max(0, accuracy),
            'timeliness_hours': hours_old,
            'timeliness_score': timeliness
        }
        
        # Overall quality score
        overall_score = (completeness + accuracy + timeliness) / 3
        validation_report['overall_score'] = overall_score
        
        # Store validation results
        await self._store_data_quality_metrics(symbol, validation_report)
        
        return validation_report
    
    async def _store_historical_data(self, symbol: str, data: pd.DataFrame):
        """Store historical data in DuckDB for backtesting."""
        try:
            # Prepare data for insertion
            data_records = []
            for date, row in data.iterrows():
                data_records.append({
                    'symbol': symbol,
                    'date': date.date(),
                    'open': float(row['Open']),
                    'high': float(row['High']),
                    'low': float(row['Low']),
                    'close': float(row['Close']),
                    'volume': int(row['Volume']),
                    'adjusted_close': float(row.get('Adj Close', row['Close']))
                })
            
            # Delete existing data for this symbol
            self.duckdb_conn.execute("DELETE FROM historical_prices WHERE symbol = ?", [symbol])
            
            # Insert new data
            self.duckdb_conn.executemany("""
                INSERT INTO historical_prices 
                (symbol, date, open, high, low, close, volume, adjusted_close)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, [(r['symbol'], r['date'], r['open'], r['high'], r['low'], 
                   r['close'], r['volume'], r['adjusted_close']) for r in data_records])
            
            logger.info(f"✅ Stored {len(data_records)} historical records for {symbol}")
            
        except Exception as e:
            logger.error(f"❌ Failed to store historical data for {symbol}: {str(e)}")
            raise
    
    async def _store_data_quality_metrics(self, dataset: str, validation_report: Dict[str, Any]):
        """Store data quality metrics for user monitoring."""
        try:
            async with self.async_session() as session:
                insert_sql = """
                    INSERT INTO data_quality_metrics 
                    (dataset, quality_score, completeness, accuracy, timeliness_hours, issues)
                    VALUES (:dataset, :quality_score, :completeness, :accuracy, :timeliness_hours, :issues)
                """
                
                await session.execute(sa.text(insert_sql), {
                    'dataset': dataset,
                    'quality_score': validation_report['overall_score'],
                    'completeness': validation_report['metrics']['completeness'],
                    'accuracy': validation_report['metrics']['accuracy'],
                    'timeliness_hours': validation_report['metrics']['timeliness_hours'],
                    'issues': validation_report
                })
                
                await session.commit()
                
        except Exception as e:
            logger.error(f"❌ Failed to store data quality metrics: {str(e)}")
    
    async def health_check(self) -> Dict[str, Any]:
        """Comprehensive health check for user validation."""
        health_status = {
            'healthy': True,
            'components': {},
            'message': 'All systems operational'
        }
        
        try:
            # Database health
            db_health = await self.check_database()
            health_status['components']['database'] = db_health
            
            # DuckDB health
            duckdb_health = await self.check_duckdb()
            health_status['components']['duckdb'] = duckdb_health
            
            # External APIs health
            api_health = await self.check_external_apis()
            health_status['components']['external_apis'] = api_health
            
            # Overall health
            component_health = [comp['healthy'] for comp in health_status['components'].values()]
            health_status['healthy'] = all(component_health)
            
            if not health_status['healthy']:
                health_status['message'] = 'Some components need attention'
            
            # Log system health
            log_system_health('data_pipeline', health_status['healthy'], health_status)
            
            return health_status
            
        except Exception as e:
            logger.error(f"❌ Health check failed: {str(e)}")
            return {
                'healthy': False,
                'error': str(e),
                'message': 'Health check failed'
            }
    
    async def check_database(self) -> Dict[str, Any]:
        """Check PostgreSQL database health."""
        try:
            async with self.db_engine.begin() as conn:
                result = await conn.execute(sa.text("SELECT 1"))
                await result.fetchone()
            
            return {'healthy': True, 'message': 'Database connection OK'}
        except Exception as e:
            return {'healthy': False, 'message': f'Database error: {str(e)}'}
    
    async def check_duckdb(self) -> Dict[str, Any]:
        """Check DuckDB health."""
        try:
            result = self.duckdb_conn.execute("SELECT COUNT(*) FROM historical_prices").fetchone()
            record_count = result[0] if result else 0
            
            return {
                'healthy': True, 
                'message': f'DuckDB OK - {record_count} historical records'
            }
        except Exception as e:
            return {'healthy': False, 'message': f'DuckDB error: {str(e)}'}
    
    async def check_external_apis(self) -> Dict[str, Any]:
        """Check external API health."""
        try:
            # Quick yfinance test
            ticker = yf.Ticker("AAPL")
            info = ticker.info
            
            if info and 'symbol' in info:
                return {'healthy': True, 'message': 'External APIs accessible'}
            else:
                return {'healthy': False, 'message': 'Limited API access'}
                
        except Exception as e:
            return {'healthy': False, 'message': f'API error: {str(e)}'}
    
    async def get_user_dashboard_data(self) -> Dict[str, Any]:
        """Get data for user dashboard display."""
        try:
            # Get recent data quality metrics
            async with self.async_session() as session:
                quality_sql = """
                    SELECT dataset, quality_score, created_at
                    FROM data_quality_metrics
                    ORDER BY created_at DESC
                    LIMIT 10
                """
                result = await session.execute(sa.text(quality_sql))
                quality_metrics = [dict(row) for row in result]
            
            # Get DuckDB statistics
            price_stats = self.duckdb_conn.execute("""
                SELECT 
                    COUNT(DISTINCT symbol) as symbols,
                    COUNT(*) as total_records,
                    MIN(date) as earliest_date,
                    MAX(date) as latest_date
                FROM historical_prices
            """).fetchone()
            
            return {
                'data_quality': quality_metrics,
                'historical_data': {
                    'symbols': price_stats[0] if price_stats else 0,
                    'total_records': price_stats[1] if price_stats else 0,
                    'date_range': {
                        'start': str(price_stats[2]) if price_stats and price_stats[2] else None,
                        'end': str(price_stats[3]) if price_stats and price_stats[3] else None
                    }
                }
            }
            
        except Exception as e:
            logger.error(f"❌ Failed to get dashboard data: {str(e)}")
            return {'error': str(e)}
