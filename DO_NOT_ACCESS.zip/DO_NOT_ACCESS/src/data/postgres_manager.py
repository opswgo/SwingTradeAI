"""
SwingTradeAI - PostgreSQL Integration and Data Versioning
User Acceptance: User can see data lineage and version history with rollback capability
"""

import asyncpg
import pandas as pd
import json
import hashlib
from typing import Dict, List, Optional, Any, Tuple
from datetime import datetime, timedelta
from pathlib import Path
import asyncio

from ..core.config import Settings
from ..core.logger import setup_logger, log_user_action, log_data_quality, log_performance_metric

logger = setup_logger(__name__)


class DataVersion:
    """Data version metadata for tracking changes."""
    
    def __init__(self, version_id: str, created_at: datetime, description: str, 
                 data_hash: str, parent_version: Optional[str] = None):
        self.version_id = version_id
        self.created_at = created_at
        self.description = description
        self.data_hash = data_hash
        self.parent_version = parent_version


class PostgreSQLManager:
    """
    PostgreSQL integration with data versioning and user-friendly management.
    User Focus: Transparent data lineage and easy rollback capabilities
    """
    
    def __init__(self, settings: Settings):
        self.settings = settings
        self.pool = None
        self.version_history = {}
        
        # Parse PostgreSQL URL
        self.db_config = self._parse_database_url(settings.DATABASE_URL)
        
    def _parse_database_url(self, database_url: str) -> Dict[str, str]:
        """Parse PostgreSQL connection URL."""
        try:
            # Handle both postgresql:// and postgres:// schemes
            if database_url.startswith('postgresql://') or database_url.startswith('postgres://'):
                # Remove scheme
                url_parts = database_url.split('://', 1)[1]
                
                # Split user:pass@host:port/database
                if '@' in url_parts:
                    auth_part, host_part = url_parts.split('@', 1)
                    if ':' in auth_part:
                        user, password = auth_part.split(':', 1)
                    else:
                        user, password = auth_part, ''
                else:
                    user, password = 'postgres', ''
                    host_part = url_parts
                
                # Parse host:port/database
                if '/' in host_part:
                    host_port, database = host_part.split('/', 1)
                else:
                    host_port, database = host_part, 'postgres'
                
                if ':' in host_port:
                    host, port = host_port.split(':', 1)
                else:
                    host, port = host_port, '5432'
                
                return {
                    'host': host,
                    'port': int(port),
                    'database': database,
                    'user': user,
                    'password': password
                }
            else:
                # Fallback for localhost
                return {
                    'host': 'localhost',
                    'port': 5432,
                    'database': 'swingtradeai',
                    'user': 'postgres',
                    'password': 'password'
                }
                
        except Exception as e:
            logger.warning(f"⚠️ Database URL parsing failed: {str(e)}, using defaults")
            return {
                'host': 'localhost',
                'port': 5432,
                'database': 'swingtradeai',
                'user': 'postgres',
                'password': 'password'
            }
    
    async def initialize(self) -> Dict[str, Any]:
        """Initialize PostgreSQL connection pool and schema."""
        logger.info("🐘 Initializing PostgreSQL connection...")
        
        try:
            # Create connection pool
            self.pool = await asyncpg.create_pool(
                host=self.db_config['host'],
                port=self.db_config['port'],
                database=self.db_config['database'],
                user=self.db_config['user'],
                password=self.db_config['password'],
                min_size=2,
                max_size=10,
                command_timeout=60
            )
            
            # Create schema
            await self._create_schema()
            
            # Load version history
            await self._load_version_history()
            
            logger.info("✅ PostgreSQL initialized successfully")
            return {
                'success': True,
                'message': 'PostgreSQL ready with versioning',
                'connection_info': {
                    'host': self.db_config['host'],
                    'port': self.db_config['port'],
                    'database': self.db_config['database']
                }
            }
            
        except Exception as e:
            logger.error(f"❌ PostgreSQL initialization failed: {str(e)}")
            return {
                'success': False,
                'error': str(e),
                'fallback_message': 'Will use DuckDB as fallback storage'
            }
    
    async def _create_schema(self):
        """Create database schema with versioning support."""
        try:
            async with self.pool.acquire() as conn:
                # Create extensions
                await conn.execute("CREATE EXTENSION IF NOT EXISTS \"uuid-ossp\"")
                
                # Market data table with versioning
                await conn.execute("""
                    CREATE TABLE IF NOT EXISTS market_data (
                        id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
                        symbol VARCHAR(10) NOT NULL,
                        date DATE NOT NULL,
                        open_price DECIMAL(10,4),
                        high_price DECIMAL(10,4),
                        low_price DECIMAL(10,4),
                        close_price DECIMAL(10,4),
                        volume BIGINT,
                        adjusted_close DECIMAL(10,4),
                        version_id VARCHAR(50) NOT NULL,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        UNIQUE(symbol, date, version_id)
                    )
                """)
                
                # Features table with versioning
                await conn.execute("""
                    CREATE TABLE IF NOT EXISTS features (
                        id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
                        symbol VARCHAR(10) NOT NULL,
                        date DATE NOT NULL,
                        feature_name VARCHAR(100) NOT NULL,
                        feature_value DECIMAL(15,6),
                        feature_metadata JSONB,
                        version_id VARCHAR(50) NOT NULL,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        UNIQUE(symbol, date, feature_name, version_id)
                    )
                """)
                
                # Data versions table
                await conn.execute("""
                    CREATE TABLE IF NOT EXISTS data_versions (
                        version_id VARCHAR(50) PRIMARY KEY,
                        parent_version VARCHAR(50),
                        description TEXT NOT NULL,
                        data_hash VARCHAR(64) NOT NULL,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        created_by VARCHAR(100) DEFAULT 'system',
                        is_active BOOLEAN DEFAULT TRUE,
                        metadata JSONB
                    )
                """)
                
                # Backtests table with versioning
                await conn.execute("""
                    CREATE TABLE IF NOT EXISTS backtests (
                        id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
                        backtest_name VARCHAR(200) NOT NULL,
                        strategy_config JSONB NOT NULL,
                        data_version VARCHAR(50) NOT NULL,
                        results JSONB NOT NULL,
                        performance_metrics JSONB,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        FOREIGN KEY (data_version) REFERENCES data_versions(version_id)
                    )
                """)
                
                # Create indexes for performance
                indexes = [
                    "CREATE INDEX IF NOT EXISTS idx_market_data_symbol_date ON market_data(symbol, date)",
                    "CREATE INDEX IF NOT EXISTS idx_market_data_version ON market_data(version_id)",
                    "CREATE INDEX IF NOT EXISTS idx_features_symbol_date ON features(symbol, date)",
                    "CREATE INDEX IF NOT EXISTS idx_features_name ON features(feature_name)",
                    "CREATE INDEX IF NOT EXISTS idx_features_version ON features(version_id)",
                    "CREATE INDEX IF NOT EXISTS idx_versions_created ON data_versions(created_at)",
                    "CREATE INDEX IF NOT EXISTS idx_versions_active ON data_versions(is_active)"
                ]
                
                for index_sql in indexes:
                    await conn.execute(index_sql)
                
                logger.info("✅ PostgreSQL schema created with versioning support")
                
        except Exception as e:
            logger.error(f"❌ Schema creation failed: {str(e)}")
            raise
    
    async def create_data_version(
        self, 
        description: str, 
        data_hash: str, 
        parent_version: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None
    ) -> str:
        """
        Create a new data version.
        
        Args:
            description: Human-readable description of changes
            data_hash: Hash of the data for integrity checking
            parent_version: Parent version ID for lineage tracking
            metadata: Additional version metadata
            
        Returns:
            New version ID
        """
        log_user_action("create_data_version", {"description": description})
        
        try:
            # Generate version ID
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            version_id = f"v_{timestamp}_{data_hash[:8]}"
            
            async with self.pool.acquire() as conn:
                # Insert version record
                await conn.execute("""
                    INSERT INTO data_versions 
                    (version_id, parent_version, description, data_hash, metadata)
                    VALUES ($1, $2, $3, $4, $5)
                """, version_id, parent_version, description, data_hash, 
                json.dumps(metadata) if metadata else None)
                
                # Deactivate previous active versions if this is a new main version
                if not parent_version:
                    await conn.execute("""
                        UPDATE data_versions 
                        SET is_active = FALSE 
                        WHERE version_id != $1 AND is_active = TRUE
                    """, version_id)
            
            # Update local cache
            version_obj = DataVersion(version_id, datetime.now(), description, data_hash, parent_version)
            self.version_history[version_id] = version_obj
            
            logger.info(f"✅ Created data version: {version_id}")
            return version_id
            
        except Exception as e:
            logger.error(f"❌ Data version creation failed: {str(e)}")
            raise
    
    async def store_market_data(
        self, 
        symbol: str, 
        data: pd.DataFrame, 
        version_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Store market data with versioning.
        
        Args:
            symbol: Stock symbol
            data: OHLCV DataFrame
            version_id: Data version (creates new if None)
            
        Returns:
            Storage result with version information
        """
        start_time = datetime.now()
        log_user_action("store_market_data", {"symbol": symbol, "records": len(data)})
        
        try:
            # Calculate data hash for integrity
            data_hash = self._calculate_data_hash(data)
            
            # Create version if not provided
            if not version_id:
                version_id = await self.create_data_version(
                    description=f"Market data for {symbol}",
                    data_hash=data_hash,
                    metadata={"symbol": symbol, "record_count": len(data)}
                )
            
            # Prepare data for insertion
            records = []
            for date, row in data.iterrows():
                records.append((
                    symbol,
                    date.date() if hasattr(date, 'date') else date,
                    float(row.get('Open', 0)),
                    float(row.get('High', 0)),
                    float(row.get('Low', 0)),
                    float(row.get('Close', 0)),
                    int(row.get('Volume', 0)),
                    float(row.get('Adj Close', row.get('Close', 0))),
                    version_id
                ))
            
            # Bulk insert
            async with self.pool.acquire() as conn:
                # Delete existing data for this symbol/version
                await conn.execute("""
                    DELETE FROM market_data 
                    WHERE symbol = $1 AND version_id = $2
                """, symbol, version_id)
                
                # Insert new data
                await conn.executemany("""
                    INSERT INTO market_data 
                    (symbol, date, open_price, high_price, low_price, close_price, volume, adjusted_close, version_id)
                    VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
                """, records)
            
            # Calculate performance metrics
            end_time = datetime.now()
            processing_time = (end_time - start_time).total_seconds()
            
            log_performance_metric("postgres_market_data_storage", processing_time, "seconds")
            log_data_quality(f"market_data_{symbol}", 1.0, [])  # Assume good quality for now
            
            logger.info(f"✅ Stored market data for {symbol}: {len(records)} records in version {version_id}")
            
            return {
                'success': True,
                'symbol': symbol,
                'version_id': version_id,
                'records_stored': len(records),
                'processing_time': processing_time,
                'data_hash': data_hash
            }
            
        except Exception as e:
            logger.error(f"❌ Market data storage failed for {symbol}: {str(e)}")
            return {
                'success': False,
                'symbol': symbol,
                'error': str(e)
            }
    
    async def store_features(
        self, 
        symbol: str, 
        features_data: pd.DataFrame, 
        version_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Store feature data with versioning.
        
        Args:
            symbol: Stock symbol
            features_data: Features DataFrame
            version_id: Data version (creates new if None)
            
        Returns:
            Storage result with version information
        """
        start_time = datetime.now()
        log_user_action("store_features", {"symbol": symbol, "features": len(features_data.columns)})
        
        try:
            # Calculate data hash
            data_hash = self._calculate_data_hash(features_data)
            
            # Create version if not provided
            if not version_id:
                version_id = await self.create_data_version(
                    description=f"Features for {symbol}",
                    data_hash=data_hash,
                    metadata={"symbol": symbol, "feature_count": len(features_data.columns)}
                )
            
            # Prepare feature records
            records = []
            for date, row in features_data.iterrows():
                for feature_name, value in row.items():
                    if pd.notna(value):
                        records.append((
                            symbol,
                            date.date() if hasattr(date, 'date') else date,
                            feature_name,
                            float(value),
                            None,  # feature_metadata (could be expanded)
                            version_id
                        ))
            
            # Bulk insert
            async with self.pool.acquire() as conn:
                # Delete existing features for this symbol/version
                await conn.execute("""
                    DELETE FROM features 
                    WHERE symbol = $1 AND version_id = $2
                """, symbol, version_id)
                
                # Insert new features
                await conn.executemany("""
                    INSERT INTO features 
                    (symbol, date, feature_name, feature_value, feature_metadata, version_id)
                    VALUES ($1, $2, $3, $4, $5, $6)
                """, records)
            
            # Calculate performance metrics
            end_time = datetime.now()
            processing_time = (end_time - start_time).total_seconds()
            
            log_performance_metric("postgres_features_storage", processing_time, "seconds")
            
            logger.info(f"✅ Stored features for {symbol}: {len(records)} feature records in version {version_id}")
            
            return {
                'success': True,
                'symbol': symbol,
                'version_id': version_id,
                'feature_records_stored': len(records),
                'processing_time': processing_time,
                'data_hash': data_hash
            }
            
        except Exception as e:
            logger.error(f"❌ Feature storage failed for {symbol}: {str(e)}")
            return {
                'success': False,
                'symbol': symbol,
                'error': str(e)
            }
    
    async def retrieve_market_data(
        self, 
        symbol: str, 
        version_id: Optional[str] = None,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None
    ) -> Dict[str, Any]:
        """
        Retrieve market data with version support.
        
        Args:
            symbol: Stock symbol
            version_id: Specific version (latest active if None)
            start_date: Start date filter
            end_date: End date filter
            
        Returns:
            Market data with version information
        """
        start_time = datetime.now()
        log_user_action("retrieve_market_data", {"symbol": symbol, "version_id": version_id})
        
        try:
            # Get version to use
            if not version_id:
                version_id = await self._get_active_version()
            
            # Build query
            conditions = ["symbol = $1", "version_id = $2"]
            params = [symbol, version_id]
            param_count = 2
            
            if start_date:
                param_count += 1
                conditions.append(f"date >= ${param_count}")
                params.append(start_date.date())
            
            if end_date:
                param_count += 1
                conditions.append(f"date <= ${param_count}")
                params.append(end_date.date())
            
            query = f"""
                SELECT date, open_price, high_price, low_price, close_price, volume, adjusted_close
                FROM market_data
                WHERE {' AND '.join(conditions)}
                ORDER BY date
            """
            
            async with self.pool.acquire() as conn:
                rows = await conn.fetch(query, *params)
            
            # Convert to DataFrame
            if rows:
                df = pd.DataFrame([
                    {
                        'Date': row['date'],
                        'Open': float(row['open_price']),
                        'High': float(row['high_price']),
                        'Low': float(row['low_price']),
                        'Close': float(row['close_price']),
                        'Volume': int(row['volume']),
                        'Adj Close': float(row['adjusted_close'])
                    }
                    for row in rows
                ])
                df.set_index('Date', inplace=True)
            else:
                df = pd.DataFrame()
            
            # Calculate performance metrics
            end_time = datetime.now()
            retrieval_time = (end_time - start_time).total_seconds()
            
            log_performance_metric("postgres_market_data_retrieval", retrieval_time, "seconds")
            
            logger.info(f"✅ Retrieved market data for {symbol}: {len(df)} records from version {version_id}")
            
            return {
                'success': True,
                'symbol': symbol,
                'version_id': version_id,
                'data': df,
                'records_retrieved': len(df),
                'retrieval_time': retrieval_time
            }
            
        except Exception as e:
            logger.error(f"❌ Market data retrieval failed for {symbol}: {str(e)}")
            return {
                'success': False,
                'symbol': symbol,
                'error': str(e),
                'data': pd.DataFrame()
            }
    
    async def get_version_history(self, limit: int = 20) -> Dict[str, Any]:
        """
        Get data version history for user review.
        
        Args:
            limit: Maximum number of versions to return
            
        Returns:
            Version history with user-friendly information
        """
        log_user_action("get_version_history", {"limit": limit})
        
        try:
            async with self.pool.acquire() as conn:
                rows = await conn.fetch("""
                    SELECT version_id, parent_version, description, data_hash, 
                           created_at, is_active, metadata
                    FROM data_versions
                    ORDER BY created_at DESC
                    LIMIT $1
                """, limit)
            
            # Format for user display
            versions = []
            for row in rows:
                metadata = json.loads(row['metadata']) if row['metadata'] else {}
                
                versions.append({
                    'version_id': row['version_id'],
                    'parent_version': row['parent_version'],
                    'description': row['description'],
                    'created_at': row['created_at'].isoformat(),
                    'is_active': row['is_active'],
                    'data_hash': row['data_hash'][:16] + '...',  # Truncate for display
                    'metadata': metadata,
                    'user_display': f"{'🟢' if row['is_active'] else '⚪'} {row['version_id']} - {row['description']}"
                })
            
            return {
                'success': True,
                'versions': versions,
                'total_versions': len(versions),
                'active_version': next((v['version_id'] for v in versions if v['is_active']), None),
                'user_message': f"Found {len(versions)} data versions"
            }
            
        except Exception as e:
            logger.error(f"❌ Version history retrieval failed: {str(e)}")
            return {
                'success': False,
                'error': str(e),
                'versions': []
            }
    
    async def rollback_to_version(self, version_id: str, description: str) -> Dict[str, Any]:
        """
        Rollback to a specific data version.
        
        Args:
            version_id: Target version to rollback to
            description: Description of rollback reason
            
        Returns:
            Rollback result
        """
        log_user_action("rollback_to_version", {"version_id": version_id})
        
        try:
            async with self.pool.acquire() as conn:
                # Check if version exists
                version_exists = await conn.fetchval("""
                    SELECT EXISTS(SELECT 1 FROM data_versions WHERE version_id = $1)
                """, version_id)
                
                if not version_exists:
                    return {
                        'success': False,
                        'error': f'Version {version_id} not found'
                    }
                
                # Deactivate current active version
                await conn.execute("""
                    UPDATE data_versions SET is_active = FALSE WHERE is_active = TRUE
                """)
                
                # Activate target version
                await conn.execute("""
                    UPDATE data_versions SET is_active = TRUE WHERE version_id = $1
                """, version_id)
                
                # Create rollback record
                rollback_version_id = await self.create_data_version(
                    description=f"Rollback: {description}",
                    data_hash="rollback",
                    parent_version=version_id,
                    metadata={"rollback_to": version_id, "reason": description}
                )
            
            logger.info(f"✅ Rolled back to version {version_id}")
            
            return {
                'success': True,
                'target_version': version_id,
                'rollback_version': rollback_version_id,
                'message': f'Successfully rolled back to version {version_id}'
            }
            
        except Exception as e:
            logger.error(f"❌ Rollback failed: {str(e)}")
            return {
                'success': False,
                'error': str(e)
            }
    
    def _calculate_data_hash(self, data: pd.DataFrame) -> str:
        """Calculate hash of DataFrame for integrity checking."""
        try:
            # Convert DataFrame to string representation and hash
            data_str = data.to_string()
            return hashlib.sha256(data_str.encode()).hexdigest()
        except Exception as e:
            logger.warning(f"⚠️ Data hash calculation failed: {str(e)}")
            return hashlib.sha256(str(datetime.now()).encode()).hexdigest()
    
    async def _get_active_version(self) -> Optional[str]:
        """Get currently active data version."""
        try:
            async with self.pool.acquire() as conn:
                version_id = await conn.fetchval("""
                    SELECT version_id FROM data_versions 
                    WHERE is_active = TRUE 
                    ORDER BY created_at DESC 
                    LIMIT 1
                """)
                return version_id
        except Exception as e:
            logger.error(f"❌ Failed to get active version: {str(e)}")
            return None
    
    async def _load_version_history(self):
        """Load version history into memory for quick access."""
        try:
            async with self.pool.acquire() as conn:
                rows = await conn.fetch("""
                    SELECT version_id, parent_version, description, data_hash, created_at
                    FROM data_versions
                    ORDER BY created_at
                """)
                
                for row in rows:
                    version_obj = DataVersion(
                        row['version_id'],
                        row['created_at'],
                        row['description'],
                        row['data_hash'],
                        row['parent_version']
                    )
                    self.version_history[row['version_id']] = version_obj
                
                logger.info(f"✅ Loaded {len(rows)} versions into memory")
                
        except Exception as e:
            logger.warning(f"⚠️ Version history loading failed: {str(e)}")
    
    async def health_check(self) -> Dict[str, Any]:
        """Check PostgreSQL system health."""
        try:
            if not self.pool:
                return {
                    'healthy': False,
                    'error': 'Connection pool not initialized',
                    'message': 'PostgreSQL not connected'
                }
            
            # Test connection
            async with self.pool.acquire() as conn:
                result = await conn.fetchval("SELECT 1")
                
                # Get database statistics
                stats = await conn.fetchrow("""
                    SELECT 
                        (SELECT COUNT(*) FROM market_data) as market_records,
                        (SELECT COUNT(*) FROM features) as feature_records,
                        (SELECT COUNT(*) FROM data_versions) as versions,
                        (SELECT version_id FROM data_versions WHERE is_active = TRUE LIMIT 1) as active_version
                """)
            
            return {
                'healthy': True,
                'connection_info': {
                    'host': self.db_config['host'],
                    'port': self.db_config['port'],
                    'database': self.db_config['database']
                },
                'statistics': {
                    'market_records': stats['market_records'],
                    'feature_records': stats['feature_records'],
                    'total_versions': stats['versions'],
                    'active_version': stats['active_version']
                },
                'pool_info': {
                    'size': self.pool.get_size(),
                    'min_size': self.pool.get_min_size(),
                    'max_size': self.pool.get_max_size()
                },
                'message': 'PostgreSQL operational with versioning'
            }
            
        except Exception as e:
            logger.error(f"❌ PostgreSQL health check failed: {str(e)}")
            return {
                'healthy': False,
                'error': str(e),
                'message': 'PostgreSQL health check failed'
            }
    
    async def close(self):
        """Close PostgreSQL connection pool."""
        if self.pool:
            await self.pool.close()
            logger.info("✅ PostgreSQL connection pool closed")
